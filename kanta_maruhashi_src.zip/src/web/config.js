const config = {
  apiUrl: 'http://localhost:5228'
};

export default config;